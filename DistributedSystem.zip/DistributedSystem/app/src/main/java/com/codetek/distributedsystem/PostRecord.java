package com.codetek.distributedsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PostRecord extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_record);
    }
}